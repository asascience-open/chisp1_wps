####################################################################################################
# May 22, 2012
# 
# Simple tab delimited data importers
# Coding history:
#   Tim Cohn........25 Oct 2005 Original tab delimited code
#           ........30 Dec 2009
#   Dave Lorenz.....13 Jul 2011 Changed output to data.frame
#   Laura DeCicco ..31 Aug 2011
#   LD..............13 Sep 2011 Changed date from POSIXlt to date
#   LD..............14 Nov 2011 Separated data manipulation into it's own function
#   LD..............05 Dec 2011 Included QW data retrieval
#   Robert M Hirsch.08 Dec 2011 a few changes in populateDaily related to Q7, Q30, and output of text information
#   LD..............08 Dec 2011 updated data outputs for Daily and Sample data frames
#   RMH.............08 Dec 2011 added code to populateDaily so user can find the data gaps and use that to shorten the record request
#   LD..............09 Dec 2011 added some comments for clarity, changed date format for getSampleTabbedData
#   RMH.............09 Dec 2011 modified populateSample to handle the less than values correctly
#   RMH.............12 Dec 2011 modified daily data to follow the unit convention of storing in cms
#   LD..............13 Dec 2011 modified getSampleDataFromFile to allow for interval censored data
#   LD..............15 Dec 2011 moved zoo load to beginning of code so it loads when page is loaded, moved INFO script to separate file, fixed a bug when there was no data
#   RMH.............16 Dec 2011 modified getSampleDataFromFile to get the Uncen variable coded right
#   LD..............21 Dec 2011 added some error handling
#   RMH.............22 Dec 2011 added removeDuplicates (to get rid of multiple copies of the same sample)
#   LD..............22 Dec 2011 updated getAllQWTabData, it should be able to accept 0 to many parameter codes
#   LD..............29 Dec 2011 added header and separator defaults to getDailyDataFromFile and getSampleDataFromFile, 
#                                   included an option of either yyyy-mm-dd or mm/dd/yyyy in file uploads.
#                                   Removed getSampleTabbedData and renamed getAllQWTabData to getSampleTabData.
#                                   getSampleTabData can do everything that getSampleTabbedData could, and more.
#   RMH.............03 Jan 2012 modified removeDuplicates to handle more complex cases of duplicate data values 
#   LD..............04 Jan 2012 Separated out the code to retrieve NWIS data, so that it is it's own function. Started documenting code
#                                   with roxygen formatting.Brought in the metaDataRetrivial function. Re-named getSampleTabData to getSampleData and re-organized code.
#   LD..............05 Jan 2012 Created a populateDateColumns function so that the Daily and Sample dataframes are constructing the date columns the same. Created interactive options that default to true
#                                   interactive=FALSE will be more machine friendly.
#   LD..............06 Jan 2012 Updated removeDuplicates function with a built-in R function
#   LD..............10 Jan 2012 Finished basic documentation and examples.  Moved mergeReport and dataOverview to this file.
#   RMH.............14 Feb 2012 Small changes to reflect the way we are calling data frames in EGRET 
# Water quality imports water quality data from qwwebservices.usgs.gov
# User is asked for a USGS site number (ex: 05406470), 5 digit parameter code, start and end date - this is required  
# 
# UniqueList = a list of all of the water quality properties available
#
# The following values are available in data frame Daily:
#   Date     = date of measurement
#   Q        = daily mean of measured property (usually discharge)
#   Julian   = number of days since 1850-01-01
#   Month    = integer month (1-12) 
#   DecYear  = decimal year
#   Year     = integer year
#   Day      = integer day (1-366)
#   MonthSeq = months since 1850
#   Q7       = rolling mean of 7 days
#   Q30      = rolling mean of 30 days
#   LogQ     = ln(Q)
#   i        = index of days
#   
# The following values are available in data frame Sample:
#   Date     = date of the sample
#   ConcLow  = Lower bound for an observed concentration
#   ConcHigh = Upper bound for an observed concentration
#   ConcAve  = Average of ConcLow and ConcHigh.  If ConcLow is NA, then ConcAve = ConcHigh/2
#   Uncen    = 1 if uncensored, 0 if censored
#   Month    = month of the year (1-12)
#   DecYear  = decimal year
#   SinDY    = sin(2*pi*DecYear)
#   CosDY    = cos(2*pi*DecYear)
#
# The following are the main functions, and their required inputs are described here:
# getDVData returns the Daily data frame (as described above).  This function gets data from the NWIS web service
#         found here: http://waterservices.usgs.gov/nwis/
#         Requried inputs:
#            siteNumber = USGS site number
#            ParameterCd = 5 digit parameter code, can be found here: http://nwis.waterdata.usgs.gov/usa/nwis/pmcodes
#            StartDate = starting date for data retrieval, must be in the format yyyy-mm-dd
#            EndDate = ending date for data retrieval, must be in the format yyyy-mm-dd
#         Optional inputs:
#            interactive = default is TRUE, if TRUE, there is interaction with the user, if FALSE - machine friendly
#
# getSampleData returns the Sample data frame (as described above). This function gets data from the USGS web service:
#         found here: http://qwwebservices.usgs.gov/
#         Required inputs:
#            siteNumber = USGS site number
#            ParameterCd = 5 digit parameter code, can be found here: http://nwis.waterdata.usgs.gov/usa/nwis/pmcodes
#                          in this function, the parameter code can be left blank for all data retrieval, or multiple codes can be inputed with a semi-colen separator
#            StartDate = starting date for data retrieval, must be in the format yyyy-mm-dd
#            EndDate = ending date for data retrieval, must be in the format yyyy-mm-dd
#         Optional inputs:
#            interactive = default is TRUE, if TRUE, there is interaction with the user, if FALSE - machine friendly
#
# getDailyDataFromFile returns the Daily data frame (as described above) from a user supplied file
#         The file should be 2 colums of data, the first being dates in the format mm/dd/yyyy or yyyy-mm-dd, the second column daily discharge values
#            The columns can have names (then header=TRUE - this is the default), or they can start immediately with data (header=FALSE).
#            The file can be formatted in most standard methods (csv(default), tab delimited).  The separator input will tell R how to parse the data.
#         Required inputs:
#            filePath = path to the file (ex., '/Users/ldecicco/RCode/WRTDS/MainRCodes/DataRetrievalRCodes/ExampleData' for mac)
#                                        (ex., 'D:/LADData/R Code/WRTDS/MainRCodes/DataRetrievalRCodes/ExampleData/' for Windows)
#            fileName = file name (ex. 'ChoptankRiverFlow.txt')
#         Optional inputs:
#            interactive = default is TRUE, if TRUE, there is interaction with the user, if FALSE - machine friendly
#            header = default is TRUE, if the first row contains header information (i.e. column names), then this is TRUE and no need to specify since that is the default,
#                     if the first row does not contain header information (i.e. column names), set header = FALSE
#            separator = default is ",", a string that separates the data cells.  For example, if it's a csv file: separator=','
#                     if it's a tab delimited file: separator='\t'
#                     if separator='', R will try to determine the separator
#
# getSampleDataFromFile returns the Sample data frame (as described above) from a user supplied file
#         The file should contain a minimum of 3 columns.  The first column of the fils should be dates in the format mm/dd/yyyy or yyyy-mm-dd, the second column remark code (ex.'<'), 
#            and the 3rd being concentration values. Subsequent columns should be remark codes, then concentration values.
#            ConcHigh is the sum of all concentration values, ConcLow is the sum of uncensored concentration values.
#            The columns can have names (then header=TRUE), or they can start immediately with data (header=FALSE).
#            The file can be formatted in most standard methods (csv, tab delimited).  The separator input will tell R how to parse the data.
#         Required inputs:
#            filePath = path to the file (ex., '/Users/ldecicco/RCode/WRTDS/MainRCodes/DataRetrievalRCodes/' for mac)
#                                        (ex., 'D:/LADData/R Code/WRTDS/MainRCodes/DataRetrievalRCodes/' for Windows)
#            fileName = file name (ex. 'ChoptankRiverNitrate.csv')
#         Optional inputs:
#            header = if the first row contains header information (i.e. column names), then this is TRUE and no need to specify since that is the default,
#                     if the first row does not contain header information (i.e. column names), set header = FALSE
#            separator = a string that separates the data cells.  For example, if it's a csv file: separator=','
#                     if it's a tab delimited file: separator='\t'
#                     if separator='', R will try to determine the separator
# getMetaData accepts a USGS site number (although it is not required) and/or parameter code for water quality constituent
#         If a site number is given, the function retrieves the site information from http://waterservices.usgs.gov/
#         If a site is not given, the user must enter data manually
#         If a parameter code is given, the function retrieves constituent information from http://nwis.waterdata.usgs.gov/nwis/pmcodes/
#         If a parameter code is not given, the user must enter data manually
#         interactive = default is TRUE, if TRUE, there is interaction with the user, if FALSE - machine friendly
#
# The following are all acceptable ways to call getMetaData:
# >getMetaData() #no site number or parameter code
# >getMetaData(siteNumber="01594440", parameterCd="00665")  #both site number and code are given
# >getMetaData(parameterCd="00665") #only parameter code is given
# >getMetaData(siteNumber="01594440") #only site number is given
# Another option is to define site number and/or parameter code first, but then you must specifically define them in the function call:
# >siteNumber <- "01594440"
# >getMetaData(siteNumber=siteNumber, parameterCd="00665")
#
# At a minumum, the following INFO data frame is populated:
#    site.no = number to identify station
#    shortName = name of station to label graphs and tables
#    dec.lat.va = decimal latitude
#    dec.long.va = decimal longitude
#    drain.area.va = drainage area in units given by user (or square miles if taken from waterservices.usgs.gov)
#    drainSqKm = drainage area in square kilometers
#    staAbbrev = station abbreviation
#    sequence = site sequence number (useful for batch processing)
#    param.nm = name of the constituent for the water quality
#    paramShortName = water quality constituent name to be used for graphs and tables
#    constitAbbrev = constituent abbreviation
#    param.units = units of water quality constituent
#
#####################################################################################################

#' Retrieval functions for USGS data
#'
#' \tabular{ll}{
#' Package: \tab dataRetrieval\cr
#' Type: \tab Package\cr
#' Version: \tab 1.0.4\cr
#' Date: \tab 2012-06-19\cr
#' License: \tab GPL (>= 2)\cr
#' LazyLoad: \tab yes\cr
#' }
#'
#' Collection of functions to help retrieve USGS data from either web services or user provided data files.
#'
#' @name dataRetrieval-package
#' @docType package
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}, Laura De Cicco \email{ldecicco@@usgs.gov}
#' @references Hirsch, R. M., Moyer, D. L. and Archfield, S. A. (2010), Weighted Regressions on Time, Discharge, and Season (WRTDS), with an Application to Chesapeake Bay River Inputs. JAWRA Journal of the American Water Resources Association, 46: 857-880. doi: 10.1111/j.1752-1688.2010.00482.x
#' @keywords data, retrieval
NULL

#' Example Water Quality Data included in dataRetrieval
#'
#' Example data representing Nitrate from the Choptank River at Greensboro, MD, USGS data
#'
#' @name ChoptankRiverNitrate
#' @docType data
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}
#' @keywords water quality data
NULL

#' Example Streamflow Data included in dataRetrieval
#'
#' Example data representing Streamflow and Nitrate from the Choptank River at Greensboro, MD, USGS data
#'
#' @name ChoptankRiverFlow
#' @docType data
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}
#' @keywords water flow data
NULL

#' Flux units included in dataRetrieval
#'
#' Flux units
#'
#' @name FLUX_UNIT
#' @docType data
NULL

#' Sample Dataframe included in dataRetrieval
#'
#' Initial Sample data frame from the Choptank River
#'
#' @name exSample
#' @docType data
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}
#' @keywords water flow data
NULL

#' Daily Dataframe included in dataRetrieval
#'
#' Initial Daily data frame from the Choptank River
#'
#' @name exDaily
#' @docType data
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}
#' @keywords water flow data
NULL

#####################################################################################################
# Functions that get data from web:


#' Data Import for USGS NWIS Data
#'
#' Imports data from NWIS web service. This function gets the data from here: \url{http://waterservices.usgs.gov/}
#' A list of parameter codes can be found here: \url{http://nwis.waterdata.usgs.gov/nwis/pmcodes/}
#' A list of statistic codes can be found here: \url{http://nwis.waterdata.usgs.gov/nwis/help/?read_file=stat&format=table}
#'
#' @param siteNumber string USGS site number.  This is usually an 8 digit number
#' @param ParameterCd string USGS parameter code.  This is usually an 5 digit number.
#' @param StartDate string starting date for data retrieval in the form YYYY-MM-DD.
#' @param EndDate string ending date for data retrieval in the form YYYY-MM-DD.
#' @param StatCd string USGS statistic code. This is usually 5 digits.  Daily mean (00003) is the default.
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import USGS web service
#' @return retval dataframe with agency, site, dateTime, value, and code columns
#' @export
#' @examples
#' # These examples require an internet connection to run
#' retrieveNWISData('01594440','00060', '1985-01-01', '1985-01-31')
#' retrieveNWISData('05114000','00010', '1985-01-01', '1985-01-31', StatCd='00001',interactive=FALSE)
retrieveNWISData <- function (siteNumber,ParameterCd,StartDate,EndDate,StatCd="00003",interactive=TRUE){  
  siteNumber <- formatCheckSiteNumber(siteNumber, interactive=interactive)
  ParameterCd <- formatCheckParameterCd(ParameterCd, interactive=interactive)
  StartDate <- formatCheckDate(StartDate, "StartDate", interactive=interactive)
  EndDate <- formatCheckDate(EndDate, "EndDate", interactive=interactive)
  
  dateReturn <- checkStartEndDate(StartDate, EndDate, interactive=interactive)
  StartDate <- dateReturn[1]
  EndDate <- dateReturn[2]
  
  baseURL <- "http://waterservices.usgs.gov/nwis/dv?site="
  
  url <- paste(baseURL,siteNumber, "&ParameterCd=",ParameterCd, "&StatCd=", StatCd, "&format=rdb,1.0", sep = "")
  
  if (nzchar(StartDate)) {
    url <- paste(url,"&startDT=",StartDate,sep="")
  } else url <- paste(url,"&startDT=","1851-01-01",sep="")
  
  if (nzchar(EndDate)) {
    url <- paste(url,"&endDT=",EndDate,sep="")
  }
  
  tmp <- read.delim(  
       url, 
       header = FALSE, 
       quote="\"", 
       dec=".", 
       sep='\t',
       colClasses=c('character'),
       fill = TRUE, 
       comment.char="#")
  col.nm <- make.names(unlist(tmp[1,, drop=TRUE]), allow_=FALSE)
  retval <- lapply(tmp, function(x) {
    Typ <- x[2] # The type - the second row shows the type (such as 5s = a string with 5 letters, 20d = a date, etc)
    x <- x[-c(1,2)] # the data - takes away the first 2 rows (1st = header, 2nd = type)
    if(regexpr('d$', Typ) > 0) { # Must be date
      ret.val <- try(as.Date(x)) # The data are in standard format, but...
      if(class(ret.val) == "try-error")
        ret.val <- x
    }
    else if(regexpr('n$', Typ) > 0) # Must be numeric
      ret.val <- as.numeric(x)
    else # Must be character
      ret.val <- x
    return(ret.val)})
  retval <- as.data.frame(retval, stringsAsFactors=FALSE)  
  names(retval) <- c('agency', 'site', 'dateTime', 'value', 'code')  
  return (retval)
}

#' USGS Site File Data Retrieval
#'
#' Imports data from USGS site file site. This function gets data from here: \url{http://waterservices.usgs.gov/}
#'
#' @param siteNumber string USGS site number.  This is usually an 8 digit number
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import USGS web service
#' @return retval dataframe with all information found in the expanded site file
#' @export
#' @examples
#' # These examples require an internet connection to run
#' getSiteFileData('05114000',interactive=FALSE)
getSiteFileData <- function(siteNumber="",interactive=TRUE){
  siteNumber <- formatCheckSiteNumber(siteNumber, interactive=interactive)
  urlSitefile <- paste("http://waterservices.usgs.gov/nwis/site?format=rdb&siteOutput=Expanded&sites=",siteNumber,sep = "")
  SiteFile <- read.delim(  
       urlSitefile, 
       header = FALSE, 
       quote="\"", 
       dec=".", 
       sep='\t',
       colClasses=c('character'),
       fill = TRUE, 
       comment.char="#")

  col.nm <- make.names(unlist(SiteFile[1,, drop=TRUE]), allow_=FALSE)
  retval <- lapply(SiteFile, function(x) {
    Typ <- x[2] # The type
    x <- x[-c(1,2)] # the data
    if(regexpr('d$', Typ) > 0) { # Must be date
      ret.val <- try(as.Date(x)) # The data are in standard format, but...
      if(class(ret.val) == "try-error")
        ret.val <- x
    }
    else if(regexpr('n$', Typ) > 0) # Must be numeric
      ret.val <- as.numeric(x)
    else # Must be character
      ret.val <- x
    return(ret.val)})
  INFO <- as.data.frame(retval, stringsAsFactors=FALSE)
  names(INFO) <- col.nm
  INFO$queryTime <- Sys.time()
  INFO$dec.lat.va <- as.numeric(INFO$dec.lat.va)
  INFO$dec.long.va <- as.numeric(INFO$dec.long.va)
  INFO$alt.va <- as.numeric(INFO$alt.va)

  return(INFO)
}

#' Data Import for USGS NWIS Water Quality Data
#'
#' Imports data from NWIS web service. This function gets the data from here: \url{http://qwwebservices.usgs.gov/}
#' A list of parameter codes can be found here: \url{http://nwis.waterdata.usgs.gov/nwis/pmcodes/}
#' A list of statistic codes can be found here: \url{http://nwis.waterdata.usgs.gov/nwis/help/?read_file=stat&format=table}
#'
#' @param siteNumber string USGS site number.  This is usually an 8 digit number
#' @param ParameterCd string USGS parameter code.  This is usually an 5 digit number. Multiple parameter codes can be inputted with a ';' separator.  Leaving this blank will return all of the measured values during the specified time period.
#' @param StartDate string starting date for data retrieval in the form YYYY-MM-DD.
#' @param EndDate string ending date for data retrieval in the form YYYY-MM-DD.
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import USGS web service
#' @return retval dataframe with first column dateTime, and at least one qualifier and value columns
#' (subsequent qualifier/value columns could follow depending on requested parameter codes)
#' @export
#' @examples
#' # These examples require an internet connection to run
#' getQWData('01594440','01075', '1985-01-01', '1985-03-31')
#' getQWData('05114000','', '1985-01-01', '1985-03-31')
#' getQWData('05114000','00915;00931', '1985-01-01', '1985-04-30', interactive=FALSE)
getQWData <- function(siteNumber,ParameterCd,StartDate,EndDate,interactive=TRUE){
  siteNumber <- formatCheckSiteNumber(siteNumber, interactive=interactive)
  StartDate <- formatCheckDate(StartDate, "StartDate", interactive=interactive)
  EndDate <- formatCheckDate(EndDate, "EndDate", interactive=interactive)
  
  dateReturn <- checkStartEndDate(StartDate, EndDate, interactive=interactive)
  StartDate <- dateReturn[1]
  EndDate <- dateReturn[2]
  
  if (nzchar(StartDate)){
    StartDate <- format(as.Date(StartDate), format="%m-%d-%Y")
  }
  if (nzchar(EndDate)){
    EndDate <- format(as.Date(EndDate), format="%m-%d-%Y")
  }
  
  baseURL <- "http://www.waterqualitydata.us/Result/search?siteid=USGS-"
  #   baseURL <- "http://qwwebservices.usgs.gov/Result/search?siteid=USGS-"
  url <- paste(baseURL,
               siteNumber,
               "&pCode=",
               ParameterCd,   # to get multi-parameters, use a semicolen between each 5 digit code....
               "&startDateLo=",
               StartDate,
               "&startDateHi=",
               EndDate,
               "&countrycode=US&mimeType=tsv",sep = "")
  
  suppressWarnings(retval <- read.delim(url, header = TRUE, quote="\"", dec=".", sep='\t', colClasses=c('character'), fill = TRUE))
  
  qualifier <- ifelse((
      (
        retval$ResultDetectionConditionText == "Not Detected"
        & length(grep("Lower", retval$DetectionQuantitationLimitTypeName)) > 0
      )
    | 
      (
        retval$ResultMeasureValue < retval$DetectionQuantitationLimitMeasure.MeasureValue
        & retval$ResultValueTypeName == "Actual"
       )
    ),
    "<",
    ""
  )
  
  correctedData<-ifelse((nchar(qualifier)==0),retval$ResultMeasureValue,retval$DetectionQuantitationLimitMeasure.MeasureValue)
  test <- data.frame(retval$USGSPCode)
  
#   test$dateTime <- as.POSIXct(strptime(paste(retval$ActivityStartDate,retval$ActivityStartTime.Time,sep=" "), "%Y-%m-%d %H:%M:%S"))
  test$dateTime <- as.Date(retval$ActivityStartDate, "%Y-%m-%d")
    
  originalLength <- nrow(test)
  test$qualifier <- qualifier
  test$value <- as.numeric(correctedData)
  
  test <- test[!is.na(test$dateTime),]
  newLength <- nrow(test)
  if (originalLength != newLength){
    numberRemoved <- originalLength - newLength
    warningMessage <- paste(numberRemoved, " rows removed because no date was specified", sep="")
    warning(warningMessage)
  }
  
  colnames(test)<- c("USGSPCode","dateTime","qualifier","value")
  data <- reshape(test, idvar="dateTime", timevar = "USGSPCode", direction="wide")    
  data$dateTime <- format(data$dateTime, "%Y-%m-%d")
  data$dateTime <- as.Date(data$dateTime)
  return(data)
}

#' USGS Parameter Data Retrieval
#'
#' Imports data from NWIS web service concerning meaured parameter based on user-supplied parameter code.
#' This function gets the data from here: \url{http://nwis.waterdata.usgs.gov/nwis/pmcodes}
#'
#' @param parameterCd string USGS parameter code.  This is usually an 5 digit number.
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import USGS web service
#' @return parameterData dataframe with all information from the USGS about the particular parameter (usually code, name, short name, units, and CAS registry numbers)
#' @export
#' @examples
#' # These examples require an internet connection to run
#' getParameterInfo('01075')
#' getParameterInfo('00931',interactive=FALSE)
getParameterInfo <- function(parameterCd,interactive=TRUE){
  parameterCd <- formatCheckParameterCd(parameterCd, interactive=interactive)
  urlParameterCd <- paste("http://nwis.waterdata.usgs.gov/nwis/pmcodes/?radio_pm_search=pm_search&pm_search=",parameterCd,"&casrn_search=&srsname_search=&format=rdb_file&show=parameter_group_nm&show=parameter_nm&show=casrn&show=srsname&show=parameter_units",sep="")
  parameterCdFile <- read.delim(  
     urlParameterCd, 
     header = TRUE, 
     quote="\"", 
     dec=".", 
     sep='\t',
     colClasses=c('character'),
     fill = TRUE, 
     comment.char="#")

  parameterData <- parameterCdFile[2,]
  return(parameterData)
}

#####################################################################################################

#####################################################################################################
# Functions that get data from user files:

#' Basic Data Import for Water Flow Data
#'
#' Imports data from user-supplied data file. Specifically used to import water flow data for use in the WRTDS package.
#' For WRTDS usage, the first column is expected to be dates, the second column measured values.
#' The third column is optional, it contains any remark codes.
#'
#' @param filePath string specifying the path to the file
#' @param fileName string name of file to open
#' @param hasHeader logical true if the first row of data is the column headers
#' @param separator string character that separates data cells
#' @keywords data import file
#' @return retval dataframe with dateTime, value, and code columns
#' @export
#' @examples
#' # Examples of how to use getDataFromFile:
#' # Change the file path and file name to something meaningful:
#' #filePath <- '~/RData/'  # Sample format
#' fileName <- 'ChoptankRiverFlow.txt'
#' #getDataFromFile(filePath,fileName, separator="\t")
getDataFromFile <- function (filePath,fileName,hasHeader=TRUE,separator=","){
  totalPath <- paste(filePath,fileName,sep="");  
  tmp <- read.delim(  
       totalPath, 
       header = hasHeader,
       sep=separator,
       colClasses=c('character'),
       fill = TRUE, 
       comment.char="#")
  
  retval <- as.data.frame(tmp, stringsAsFactors=FALSE)
  if(ncol(retval) == 2){
    names(retval) <- c('dateTime', 'value')
  } else if (ncol(retval) == 3){
    names(retval) <- c('dateTime', 'value', 'code')
  }

  if(dateFormatCheck(retval$dateTime)){
    retval$dateTime <- as.Date(retval$dateTime)  
  } else {
    retval$dateTime <- as.Date(retval$dateTime,format="%m/%d/%Y")
  }
  
  retval$value <- as.numeric(retval$value)
  return (retval)
}

#' Convert Preloaded Flow Data
#'
#' Imports data from data already pre-loaded into the R workspace. Specifically used to import water flow data for use in the WRTDS package.
#' For WRTDS usage, the first column is expected to be dates, the second column measured values.
#' The third column is optional, it contains any remark codes.
#'
#' @param rawData dataframe data already loaded into R workspace
#' @keywords data import
#' @return retval dataframe with dateTime, value, and code columns
#' @export
#' @examples
#' getPreLoadedData(ChoptankRiverFlow)
getPreLoadedData <- function (rawData){  
  retval <- as.data.frame(rawData, stringsAsFactors=FALSE)
  if(ncol(retval) == 2){
    names(retval) <- c('dateTime', 'value')
  } else if (ncol(retval) == 3){
    names(retval) <- c('dateTime', 'value', 'code')
  }
  retval$dateTime <- as.character(retval$dateTime)
  if(dateFormatCheck(retval$dateTime)){
    retval$dateTime <- as.Date(retval$dateTime)  
  } else {
    retval$dateTime <- as.Date(retval$dateTime,format="%m/%d/%Y")
  }
  
  retval$value <- as.numeric(retval$value)
  return (retval)
}

#' Convert Preloaded QW Data
#'
#' Imports data from data already pre-loaded into the R workspace. Specifically used to import water flow data for use in the WRTDS package.
#' For WRTDS usage, the first column is expected to be dates, the second column measured values.
#' The third column is optional, it contains any remark codes.
#'
#' @param rawData dataframe data already loaded into R workspace
#' @keywords data import
#' @return retval dataframe with dateTime, value, and code columns
getPreLoadedQWData <- function (rawData){  
  retval <- as.data.frame(rawData, stringsAsFactors=FALSE)
  numColumns <- ncol(retval)
  i <- 1
  while (i <= numColumns) {
    retval[[i]] <- as.character(retval[[i]])
    i <- i + 1
  }
  retval[[1]] <- as.character(retval[[1]])
  return (retval)
}

#' Basic Data Import
#'
#' Imports data from user-supplied data file. Specifically used to import water quality data for use in the WRTDS package.
#' For WRTDS usage, the first column is expected to be dates, the second column remarks (specifically < if censored data),
#' and the third column is measured values.  There can be additional columns of data, for each column of data, there should
#' be a remark column preceeding.
#'
#' @param filePath string specifying the path to the file
#' @param fileName string name of file to open
#' @param hasHeader logical true if the first row of data is the column headers
#' @param separator string character that separates data cells
#' @keywords data import file
#' @return retval dataframe
#' @export
#' @examples
#' # Examples of how to use getQWDataFromFile:
#' # Change the file path and file name to something meaningful:
#' #filePath <- '~/RData/'  # Sample format
#' fileName <- 'ChoptankRiverNitrate.csv'
#' #getQWDataFromFile(filePath,fileName, separator=";")
getQWDataFromFile <- function (filePath,fileName,hasHeader=TRUE,separator=","){
  totalPath <- paste(filePath,fileName,sep="");
  tmp <- read.delim(  
       totalPath, 
       header = hasHeader,
       sep=separator,
       colClasses=c('character'),
       fill = TRUE, 
       comment.char="#")
  
  retval <- as.data.frame(tmp, stringsAsFactors=FALSE)
  return (retval)
}

#####################################################################################################

#####################################################################################################
# Functions that check formatting:

#' Date Formatting Check
#'
#' Checks that the user-supplied date is in the format YYYY-MM-DD and month is less than 13, and dates are less than 32.
#'
#' @param date string date to check
#' @keywords data import from web service
#' @return Date logical
#' @export
#' @examples
#' dateFormatCheck('1985-01-01')
#' dateFormatCheck('01/01/1985')
dateFormatCheck <- function(date){  # checks for the format YYYY-MM-DD
  parts <- strsplit(date,"-",fixed=TRUE)
  condition <- FALSE
  if (length(parts[[1]])>1) {
    if (nchar(parts[[1]][1]) == 4 && nchar(parts[[1]][2]) == 2 && nchar(parts[[1]][3]) == 2){
      testYear <- as.numeric(parts[[1]][1])
      testMonth <- as.numeric(parts[[1]][2])
      testDay <- as.numeric(parts[[1]][3])
      if (!is.na(testYear) && !is.na(testMonth) && !is.na(testDay)){
        if (testMonth <= 12 && testDay <= 31){
          condition <- TRUE
        }        
      }      
    }
  }
  return(condition)
}

#' Site number check
#'
#' Checks that the user-supplied site number is 8 digits, typical for many USGS station site id's.If not, asks the user to re-enter.
#' The final siteNumber can be more or less than 8 digits, since there are conditions where that is the case.
#'
#' @param siteNumber string USGS site number
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords error checking for data import from web service
#' @return siteNumber string
#' @export
#' @examples
#' formatCheckSiteNumber('01594440')
#' formatCheckSiteNumber('015944400',interactive=FALSE)
formatCheckSiteNumber <- function(siteNumber, interactive=TRUE){  #checks for a 8 digit number
  if (nchar(siteNumber) != 8){
    if (interactive){
      cat("Most common USGS site numbers are 8 digits long, you entered a ", nchar(siteNumber), "digit number = ", siteNumber , ".\n")
      cat("If you would like to change the site id, enter it here (no quotes), otherwise hit return:\n")
      tempSiteID <- readline()
      if (nzchar(tempSiteID)) siteNumber <- tempSiteID
    } else {
      warningMessage <- paste("Most common USGS site numbers are 8 digits long, you entered ", siteNumber , ".", sep="")
      warning(warningMessage)
    }
  }
  return(siteNumber)
}
#' Parameter Code Check
#'
#' Checks that the user-supplied parameter code is 5 digits. If not, asks the user to re-enter.
#'
#' @param ParameterCd string USGS parameter code
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import from web service
#' @return ParameterCd string
#' @export
#' @examples
#' formatCheckParameterCd('00060')
formatCheckParameterCd <- function(ParameterCd, interactive=TRUE){     #checks for a 5 digit number
  if (nchar(ParameterCd) != 5){
    if (interactive){
      cat("Most USGS parameter codes are 5 digits long, you entered a ", nchar(ParameterCd), "digit number = ", ParameterCd , ".\n")
      cat("If you would like to change the parameter code, enter it here (no quotes), otherwise hit return:\n")
      tempParameterCd <- readline()
      if (nzchar(tempParameterCd)) ParameterCd <- tempParameterCd
    } else {
      warningMessage <- paste("Most USGS parameter codes are 5 digits long, you entered ", ParameterCd , ".", sep="")
      warning(warningMessage)
    }
  }
  return(ParameterCd)
}

#' Date Formatting Correction
#'
#' Checks that the user-supplied date is in the format YYYY-MM-DD. If not, asks the user to re-enter.
#'
#' @param Date string date to check
#' @param dateString string should be either 'StartDate' or 'EndDate'
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import from web service
#' @return Date string
#' @export
#' @examples
#' formatCheckDate('1985-01-01', 'StartDate')
formatCheckDate <- function(Date, dateString,interactive=TRUE){
  if(nzchar(Date)){
    if (!dateFormatCheck(Date)){
      if (interactive){
        cat("Date must be entered in the form YYYY-MM-DD (no quotes), you entered: ", Date, "as the StartDate.\n")
        cat("Please re-enter ", dateString, ":\n")
        Date <- readline()
      } else {
        warningMessage <- paste(dateString, " must be entered in the form YYYY-MM-DD, you entered: ", Date, ". ", dateString, " will be ignored",sep="")
        warning(warningMessage)
        Date <- ""
      }
    }
  }
  return(Date)
} 

#' Check Start End Dates
#'
#' Checks that the user-supplied starting date is before the ending date.  If not, either the user can re-enter, or the dates will be set to maximum.
#'
#' @param StartDate string date
#' @param EndDate string date
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import from web service
#' @return list StartDate,EndDate
#' @export
#' @examples
#' checkStartEndDate('1985-01-01', '1985-12-31')
checkStartEndDate <- function(StartDate, EndDate,interactive=TRUE){
  start <- as.Date("1850-01-01")
  end <- as.Date(Sys.Date())
  
  if (nzchar(StartDate)) start <- as.Date(StartDate)
  if (nzchar(EndDate)) end <- as.Date(EndDate)
  if (start > end) {
    if (interactive){
      cat ("Start date must be before end date, you entered Start = ", StartDate, " End = ", EndDate, "\n")
      cat ("please re-enter StartDate (YYYY-MM-DD) - hit Enter for earliest date as StartDate: \n")
      StartDate <- readline()
      cat("Please re-enter EndDate (YYYY-MM-DD) - hit Enter for latest date as EndDate: \n")
      EndDate <- readline()
    } else {
      warningMessage <- "Starting date was not before ending date, dates will be ignored"
      warning(warningMessage)
      StartDate <- as.Date("1851-01-01")
      EndDate <- as.Date(Sys.Date())
    }
    
  }  
  return(c(StartDate,EndDate))
}

#####################################################################################################

#####################################################################################################
# Functions that populate data frames for WRTDS codes:

#' Populate Daily data frame
#'
#' Using raw data that has at least dateTime, value, code, populates the rest of the basic Daily data frame used in WRTDS
#'
#' @param rawData dataframe contains at least dateTime, value, code columns
#' @param qConvert string conversion to cubic meters per second
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords WRTDS flow
#' @author Robert M. Hirsch \email{rhirsch@@usgs.gov}
#' @import zoo
#' @return dataframe Daily
#' @export
#' @examples
#' dateTime <- c('1985-01-01', '1985-01-02', '1985-01-03')
#' value <- c(1,2,3)
#' code <- c("","","")
#' dataInput <- data.frame(dateTime, value, code, stringsAsFactors=FALSE)
#' populateDaily(dataInput, 2, interactive=FALSE)
populateDaily <- function(rawData,qConvert,interactive=TRUE){  # rawData is a dataframe with at least dateTime, value, code
  localDaily <- as.data.frame(matrix(ncol=2,nrow=length(rawData$value)))
  colnames(localDaily) <- c('Date','Q')
  localDaily$Date <- rawData$dateTime
  
  # need to convert to cubic meters per second to store the values
  localDaily$Q <- rawData$value/qConvert

  dateFrame <- populateDateColumns(rawData$dateTime)
  localDaily <- cbind(localDaily, dateFrame[,-1])

  localDaily$Date <- as.Date(localDaily$Date)
  
  if(length(rawData$code) != 0) localDaily$Qualifier <- rawData$code
  
  localDaily$i <- 1:nrow(localDaily)
  
  noDataValue <- -999999
  nd<-ifelse(localDaily$Q==noDataValue,T,F)
  localDaily$Q<-ifelse(nd,NA,localDaily$Q)

  zeros<-which(localDaily$Q<=0)
  
  nz<-length(zeros)
  
  if(nz>0) qshift<-0.001*mean(localDaily$Q, na.rm=TRUE) else qshift<-0.0
  
  localDaily$Q<-localDaily$Q+qshift
  
  localDaily$LogQ <- log(localDaily$Q)
  
  Qzoo<-zoo(localDaily$Q)
  
  if (length(rawData$dateTime) < 30){
    if (interactive){
      cat("This program requires at least 30 data points. You have only provided:", length(rawData$dateTime),"Rolling means will not be calculated.\n")
    }
    warning("This program requires at least 30 data points. Rolling means will not be calculated.")
  } else {
    localDaily$Q7<-as.numeric(rollapply(Qzoo,7,mean,na.rm=FALSE,fill=NA,align="right"))
    localDaily$Q30<-as.numeric(rollapply(Qzoo,30,mean,na.rm=FALSE,fill=NA,align="right"))    
  }
  
  dataPoints <- nrow(localDaily)
  difference <- (localDaily$Julian[dataPoints] - localDaily$Julian[1])+1  
  if (interactive){
    cat("There are ", as.character(dataPoints), "data points, and ", as.character(difference), "days.\n")
    cat("There are ",as.character(nz), "zero flow days\n")
    cat("If there are any zero discharge days, all days had",as.character(qshift),"cubic meters per second added to the discharge value.\n")
    #these next two lines show the user where the gaps in the data are if there are any
    n<-nrow(localDaily)
    for(i in 2:n) {if((localDaily$Julian[i]-localDaily$Julian[i-1])>1) cat("\n discharge data jumps from",as.character(localDaily$Date[i-1]),"to",as.character(localDaily$Date[i]))}
  }
  
  return (localDaily)  
}

#' Compress sample data frame
#'
#' Using raw data that has at least dateTime, value, code, populates the measured data portion of the Sample data frame used in WRTDS
#' ConcLow  = Lower bound for an observed concentration
#' ConcHigh = Upper bound for an observed concentration
#' ConcAve  = Average of ConcLow and ConcHigh.  If ConcLow is NA, then ConcAve = ConcHigh/2
#' Uncen    = 1 if uncensored, 0 if censored
#'
#' @param data dataframe contains at least dateTime, value, code columns
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords WRTDS flow
#' @return dataframe returnDataFrame data frame containing dateTime, ConcHigh, ConcLow, Uncen, ConcAve
#' @export
#' @examples
#' dateTime <- c('1985-01-01', '1985-01-02', '1985-01-03')
#' comment1 <- c("","","")
#' value1 <- c(1,2,3)
#' comment2 <- c("","<","")
#' value2 <- c(2,3,4)
#' comment3 <- c("","","<")
#' value3 <- c(3,4,5)
#' dataInput <- data.frame(dateTime, comment1, value1, comment2, value2, comment3, value3, stringsAsFactors=FALSE)
#' compressData(dataInput, interactive=FALSE)
compressData <- function(data, interactive=TRUE){  
  
  data <- as.data.frame(data, stringsAsFactors=FALSE)
  numColumns <- ncol(data)
  numDataColumns <- (numColumns-1)/2
  lowConcentration <- rep(0,nrow(data))
  highConcentration <- rep(0,nrow(data))
  uncensored <- rep(0,nrow(data))

  i <- 1
  while (i <= numDataColumns) {
    code <- data[2*i]
    value <- data[2*i+1]
    value <- as.numeric(unlist(value))
    value[is.na(value)] <- 0
    returnDataFrame <- as.data.frame(matrix(ncol=2,nrow=nrow(code)))
    colnames(returnDataFrame) <- c('code','value')
    returnDataFrame$code <- code[[1]]
    returnDataFrame$code <- ifelse(is.na(returnDataFrame$code),"",returnDataFrame$code)
    returnDataFrame$value <- value
    concentrationColumns <- populateConcentrations(returnDataFrame)
    lowConcentration <- lowConcentration + concentrationColumns$ConcLow
    highConcentration <- highConcentration + concentrationColumns$ConcHigh
    i <- i + 1
  }
  
  names(data) <- c('dateTime', 'code', 'value')
  returnDataFrame <- as.data.frame(matrix(ncol=3,nrow=nrow(data)))
  names(returnDataFrame) <- c('dateTime', 'ConcLow', 'ConcHigh')
  
  data$dateTime <- as.character(data$dateTime)
  if(dateFormatCheck(data$dateTime)){
    returnDataFrame$dateTime <- as.Date(data$dateTime)  
  } else {
    data$dateTime <- as.Date(data$dateTime,format="%m/%d/%Y")
    returnDataFrame$dateTime <- as.Date(data$dateTime,format="%m/%d/%Y")
  }
  returnDataFrame$ConcLow <- as.numeric(lowConcentration)
  returnDataFrame$ConcHigh <- as.numeric(highConcentration)
  Uncen1<-ifelse(returnDataFrame$ConcLow==returnDataFrame$ConcHigh,1,0)
  returnDataFrame$Uncen<-ifelse(is.na(returnDataFrame$ConcLow),0,Uncen1)

  flaggedData1 <- returnDataFrame[(returnDataFrame$ConcLow == 0 & returnDataFrame$ConcHigh == 0),]
  returnDataFrame <- returnDataFrame[!(returnDataFrame$ConcLow == 0 & returnDataFrame$ConcHigh == 0),]
   
  if (nrow(flaggedData1) > 0){
    WarningMessage <- paste("Deleted ", nrow(flaggedData1), " rows of data because concentration was reported as 0.0, the program is unable to interpret that result and is therefore deleting it.", sep="")    
    warning(WarningMessage)
    if (interactive){
      cat("Deleted Rows:\n")
      print(flaggedData1)
    }
  }

  flaggedData2 <- returnDataFrame[(returnDataFrame$ConcLow > returnDataFrame$ConcHigh),]
  returnDataFrame <- returnDataFrame[(returnDataFrame$ConcLow <= returnDataFrame$ConcHigh),]
  
  if (nrow(flaggedData2) > 0){
    WarningMessage <- paste("Deleted ", nrow(flaggedData2), " rows of data because the high concentration was reported lower than the low concentration, the program is unable to interpret that result and is therefore deleting it.", sep="")    
    warning(WarningMessage)
    if (interactive){
      cat("Deleted Rows:\n")
      print(flaggedData2)
    }
  }
  
  return(returnDataFrame)
}

#' Populate Sample Columns
#'
#' Creates ConcAve and ConcLow based on Uncen. Removes any samples with NA values in ConcHigh
#'
#' @param rawData dataframe with dateTime, ConcLow, ConcHigh, Uncen
#' @return Sample2 dataframe
#' @export
#' @examples
#' dateTime <- c('1985-01-01', '1985-01-02', '1985-01-03')
#' ConcLow <- c(1,2,0)
#' ConcHigh <- c(1,2,3)
#' Uncen <- c(1,1,0)
#' dataInput <- data.frame(dateTime, ConcLow, ConcHigh, Uncen, stringsAsFactors=FALSE)
#' populateSampleColumns(dataInput)
populateSampleColumns <- function(rawData){  # rawData is a dataframe with dateTime, ConcLow, ConcHigh, Uncen
  Sample <- as.data.frame(matrix(ncol=3,nrow=length(rawData$dateTime)))
  colnames(Sample) <- c('Date', 'ConcLow','ConcHigh')
  Sample$Date <- rawData$dateTime
  Sample$ConcLow <- rawData$ConcLow
  Sample$ConcHigh <- rawData$ConcHigh
  Sample$Uncen <- rawData$Uncen
  Sample$ConcAve <- (Sample$ConcLow+Sample$ConcHigh)/2
  Sample$ConcLow <- ifelse((rawData$ConcLow == 0.0 & rawData$Uncen == 0),NA,rawData$ConcLow)
  
  dateFrame <- populateDateColumns(rawData$dateTime)
  Sample <- cbind(Sample, dateFrame[,-1])
  
  Sample$SinDY <- sin(2*pi*Sample$DecYear)
  Sample$CosDY <- cos(2*pi*Sample$DecYear)
  Sample2 <- subset(Sample, (!is.na(Sample$ConcHigh)))  # Was just ConcHigh.....
  return (Sample2)  
}

#' Populate Date Columns
#'
#' Creates various date columns for WRTDS study.
#'
#' @param rawData vector with dateTime
#' @return DateFrame dataframe
#' @export
#' @examples
#' dateTime <- c('1985-01-01', '1985-01-02', '1985-01-03')
#' populateDateColumns(dateTime)
populateDateColumns <- function(rawData){  # rawData is a vector of dates
  DateFrame <- as.data.frame(matrix(ncol=1,nrow=length(rawData)))
  colnames(DateFrame) <- c('Date')  
  DateFrame$Date <- rawData
  dateTime <- as.POSIXlt(rawData)
  DateFrame$Julian <- as.numeric(julian(dateTime,origin=as.Date("1850-01-01")))
  DateFrame$Month <- dateTime$mon + 1
  DateFrame$Day <- dateTime$yday + 1
  year <- dateTime$year + 1900
  DateFrame$DecYear <- year + (DateFrame$Day -0.5)/366
  DateFrame$MonthSeq <- ((year-1850)*12)+DateFrame$Month
  return (DateFrame)
  
}

#' Populate Concentration Columns
#'
#' Creates ConcLow, ConcHigh, Uncen (0 if censored, 1 if uncensored) columns for Sample data frame for WRTDS study.
#'
#' @param rawData vector with value and code columns
#' @return concentrationColumns dataframe
#' @export
#' @examples
#' code <- c("","<","")
#' value <- c(1,2,3)
#' dataInput <- data.frame(value, code, stringsAsFactors=FALSE)
#' populateConcentrations(dataInput)
populateConcentrations <- function(rawData){  # rawData is a dataframe with value, code
  concentrationColumns <- as.data.frame(matrix(ncol=3,nrow=length(rawData$value)))
  colnames(concentrationColumns) <- c('ConcLow','ConcHigh','Uncen')  
  concentrationColumns$ConcLow <- as.numeric(ifelse((rawData$code!="<" | is.na(rawData$code)),rawData$value,0))
  concentrationColumns$ConcHigh <- as.numeric(rawData$value)
  tempConcLow<-ifelse((rawData$code!="<" | is.na(rawData$code)),rawData$value,0)
  concentrationColumns$Uncen <- ifelse(tempConcLow==0,0,1)  
  return (concentrationColumns)  # returns ConcLow, ConcHigh, Uncen (0 if censored, 1 if uncensored)
}

#' Populate Site Information Columns
#'
#' Populates INFO data frame with additional user-supplied information. Also removes fields not related to WRTDS study.
#'
#' @param INFO dataframe with value and code columns
#' @param siteNumber string USGS site number
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @return INFO dataframe
#' @export
#' @examples
#' #This example requires an internet connection to run
#' exINFO <- getSiteFileData('01594440')
#' siteNumber <- "01594440"
#' populateSiteINFO(exINFO, siteNumber,interactive=FALSE)
populateSiteINFO <- function(INFO, siteNumber,interactive=TRUE){
  if (nzchar(siteNumber)){
    
    INFO$land.net.ds <- NULL
    INFO$instruments.cd <- NULL
    INFO$nat.aqfr.cd <- NULL
    INFO$aqfr.cd <- NULL
    INFO$aqfr.type.cd <- NULL
    INFO$well.depth.va <- NULL
    INFO$hole.depth.va <- NULL
    INFO$hole.depth.va <- NULL
    INFO$depth.src.cd <- NULL
    INFO$gw.file.cd <- NULL
    
    if (!nzchar(INFO$site.no)) {
      INFO$site.no <- siteNumber
    }
    
    if (interactive){
      cat("Your site for streamflow data is", as.character(INFO$site.no),".\n")
      if (!nzchar(INFO$station.nm)){
        cat("No station name was listed in the USGS site file for site: ", INFO$site.no, ". Please enter a station name here(no quotes): \n")
        INFO$station.nm <- readline()
      }
      cat("Your site name is", INFO$station.nm,",")
      cat("but you can modify this to a short name in a style you prefer. \nThis name will be used to label graphs and tables. \n")
      cat("If you want the program to use the name given above, just do a carriage return, otherwise enter the preferred short name(no quotes):\n")
      INFO$shortName <- readline()
      if (!nzchar(INFO$shortName)) INFO$shortName <- INFO$station.nm
      if (!nzchar(INFO$dec.lat.va) || !nzchar(INFO$dec.long.va)){
        cat("No latitude or longitude was listed in the USGS site file for this site.\n")
        cat("Please enter a latitude and longitude in decimal degrees, positive latitudes are north, negative are south, positive longitudes are east, \nnegative longitudes are west, so for example a site in the northeastern US might look like, 40.1, -83.2\nThese only need to be sufficiently accurate to place them on a map of the study area.\n\n")
        cat("Latitude(no quotes):\n")
        INFO$dec.lat.va <- readline()
        cat("Longitude(no quotes):\n")
        INFO$dec.long.va <- readline()
      }
      cat("The latitude and longitude of the site are: ",INFO$dec.lat.va, ", ", INFO$dec.long.va, "(degrees north and west).\n")
      if (!nzchar(INFO$drain.area.va)){
        cat("No drainage area was listed in the USGS site file for this site.\n")
        cat("Please enter the drainage area, you can enter it in the units of your choice.\nEnter the area, then enter drainage area code, 1 is square miles, 2 is square kilometers, 3 is acres, and 4 is hectares.\n")
        cat("Area(no quotes):\n")
        INFO$drain.area.va <- readline()
        INFO$drain.area.va <- as.numeric(INFO$drain.area.va)
        cat("Unit Code (1-4, no quotes):")
        qUnit <- readline()
        qUnit <- as.numeric(qUnit)
        conversionVector <- c(2.5899881, 1.0, 0.0040468564, 0.01)
        INFO$drainSqKm <- INFO$drain.area.va * conversionVector[qUnit]
      } else {
        INFO$drain.area.va <- as.numeric(INFO$drain.area.va)
        INFO$contrib.drain.area.va <- as.numeric(INFO$contrib.drain.area.va)
        INFO$drainSqKm <- INFO$drain.area.va * 2.5899881
      }    
      cat("The drainage area at this site is ", INFO$drain.area.va, "square miles which is being stored as", INFO$drainSqKm, "square kilometers.\n")    
    } else {
        INFO$drain.area.va <- as.numeric(INFO$drain.area.va)
        INFO$contrib.drain.area.va <- as.numeric(INFO$contrib.drain.area.va)
        INFO$drainSqKm <- INFO$drain.area.va * 2.5899881      
    }    
  } else {
    if (interactive){
      cat("The program needs to know a site number or id, please enter that here (don't use quotes) - Enter to leave blank:")
      INFO$site.no <- readline()
      cat("Please enter a site name that will be used to label all graphs and tables(no quotes):\n")
      INFO$shortName <- readline()
      cat("Please enter a latitude and longitude in decimal degrees, positive latitudes are north, negative are south, positive longitudes are east, \nnegative longitudes are west, so for example a site in the northeastern US might look like, 40.1, -83.2\nThese only need to be sufficiently accurate to place them on a map of the study area.\n\n")
      cat("Latitude(no quotes):\n")
      INFO$dec.lat.va <- readline()
      cat("Longitude(no quotes):\n")
      INFO$dec.long.va <- readline()
      INFO$dec.lat.va <- as.numeric(INFO$dec.lat.va)
      INFO$dec.long.va <- as.numeric(INFO$dec.long.va)
      cat("Please enter the drainage area, you can enter it in the units of your choice.\nEnter the area, then enter drainage area code, 1 is square miles, 2 is square kilometers, 3 is acres, and 4 is hectares.\n")
      cat("Area(no quotes):\n")
      INFO$drain.area.va <- readline()
      INFO$drain.area.va <- as.numeric(INFO$drain.area.va)
      cat("Unit Code (1-4, no quotes):")
      qUnit <- readline()
      qUnit <- as.numeric(qUnit)
      conversionVector <- c(2.5899881, 1.0, 0.0040468564, 0.01)
      INFO$drainSqKm <- INFO$drain.area.va * conversionVector[qUnit]
      cat("The drainage area is being stored as", INFO$drainSqKm, "square kilometers.\n")
    } else {
      INFO$site.no <- NA
      INFO$shortName <- NA
      INFO$dec.lat.va <- NA
      INFO$dec.long.va <- NA
      INFO$drain.area.va <- NA
      INFO$drainSqKm <- NA
    }
  }
  if (interactive){
    cat("It is helpful to set up a station abbreviation when doing multi-site studies, enter a unique id (three or four characters should work).\nIt is case sensitive.  Even if you don't feel you need an abbreviation for your site you need to enter something(no quotes):\n")
    INFO$staAbbrev <- readline()
  } else {
    INFO$staAbbrev <- NA
  }
  return(INFO)  
}

#' Populate Parameter Information Columns
#'
#' Populates INFO data frame with additional user-supplied information concerning the measured parameter.
#'
#' @param INFO dataframe with value and code columns
#' @param parameterCd string USGS parameter code
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @return INFO dataframe
#' @export
#' @examples
#' #This example requires an internet connection to run
#' exINFO <- getSiteFileData('01594440')
#' parameterCd <- "00175"
#' parameterData <- getParameterInfo(parameterCd,interactive=interactive)
#' exINFO$param.nm <- parameterData$parameter_nm
#' exINFO$param.units <- parameterData$parameter_units
#' exINFO$paramShortName <- parameterData$srsname
#' exINFO$paramNumber <- parameterData$parameter_cd
#' populateParameterINFO(exINFO, parameterCd,interactive=FALSE)
populateParameterINFO <- function(INFO, parameterCd, interactive=TRUE){
  if (nzchar(parameterCd)){
    if(interactive){
      cat("Your water quality data are for parameter number", INFO$paramNumber, "which has the name:'", INFO$param.nm, "'.\n")
      cat("Typically you will want a shorter name to be used in graphs and tables. The suggested short name is:'", INFO$paramShortName, "'.\n")
      cat("If you would like to change the short name, enter it here, otherwise just hit enter (no quotes):")
      shortNameTemp <- readline()
      if (nchar(shortNameTemp)>0) INFO$paramShortName <- shortNameTemp
      cat("The units for the water quality data are: ", INFO$param.units, ".\n")
      cat("It is helpful to set up a constiuent abbreviation when doing multi-constituent studies, enter a unique id (three or four characters should work something like tn or tp or NO3).\nIt is case sensitive.  Even if you don't feel you need an abbreviation you need to enter something (no quotes):\n")
      INFO$constitAbbrev <- readline()
    } else {
      INFO$constitAbbrev <- INFO$paramShortName
    }
  } else {
    if (interactive){
      INFO$paramNumber <- NA
      cat("Enter a long name for the water quality data (no quotes):\n")
      INFO$param.nm <- readline()
      cat("Enter a short name to be used in graphs and tables(no quotes):\n")
      INFO$paramShortName <- readline()
      cat("It is helpful to set up a constiuent abbreviation when doing multi-constituent studies, enter a unique id (three or four characters should work something like tn or tp or NO3).\nIt is case sensitive.  Even if you don't feel you need an abbreviation you need to enter something (no quotes):\n")
      INFO$constitAbbrev <- readline()
      cat("Enter the units of the water quality data(no quotes):\n")
      INFO$param.units <- readline()
    } else {
      INFO$paramNumber <- NA
      INFO$param.nm <- NA
      INFO$paramShortName <- NA
      INFO$constitAbbrev <- NA
      INFO$param.units <- NA      
    }
  } 
  
  return(INFO)
}

#' Remove Duplicates
#'
#' Removes observations from the data frame Sample when the observation has the identical date and value as another observation
#'
#' @param localSample dataframe with at least DecYear and ConcHigh, default name is Sample
#' @export
#' @return Sample1 dataframe
#' @examples
#' DecYear <- c('1985.01', '1985.01', '1985.02', '1985.02', '1985.03')
#' ConcHigh <- c(1,2,3,3,5)
#' dataInput <- data.frame(DecYear, ConcHigh, stringsAsFactors=FALSE)
#' removeDuplicates(dataInput)
removeDuplicates <- function(localSample=Sample) {  
  Sample1 <- localSample[!duplicated(localSample[c("DecYear","ConcHigh")]),]
  
	return(Sample1)
}

#####################################################################################################

#####################################################################################################
# Functions that bring it all together for WRTDS work:

#' Import Daily Data for WRTDS
#'
#' Imports data from NWIS web service. This function gets the data from here: \url{http://waterservices.usgs.gov/}
#' A list of parameter codes can be found here: \url{http://nwis.waterdata.usgs.gov/nwis/pmcodes/}
#' A list of statistic codes can be found here: \url{http://nwis.waterdata.usgs.gov/nwis/help/?read_file=stat&format=table}
#'
#' @param siteNumber string USGS site number.  This is usually an 8 digit number
#' @param ParameterCd string USGS parameter code.  This is usually an 5 digit number.
#' @param StartDate string starting date for data retrieval in the form YYYY-MM-DD.
#' @param EndDate string ending date for data retrieval in the form YYYY-MM-DD.
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import USGS WRTDS
#' @export
#' @return Daily dataframe
#' @seealso \code{\link{retrieveNWISData}}, \code{\link{populateDaily}}
#' @examples
#' # These examples require an internet connection to run
#' getDVData('01594440','00060', '1985-01-01', '1985-03-31', interactive=FALSE)
getDVData <- function (siteNumber,ParameterCd,StartDate,EndDate,interactive=TRUE){
  data <- retrieveNWISData(siteNumber,ParameterCd,StartDate,EndDate,interactive=interactive)
  #  need to setup conversion factor because the NWIS data are in cfs but we store in cms
  qConvert<-35.314667
  localDaily <- populateDaily(data,qConvert,interactive=interactive)
  return (localDaily)
}


#' Import Preloaded Daily Data for WRTDS use
#'
#' This function is intended to convert daily data that is already loaded into the R enviornment to the WRTDS daily data frame.
#'
#' @param loadedData dataframe that is already loaded in R session
#' @param qUnit number 1 is cubic feet per second, 2 is cubic meters per second, 3 is 10^3 cubic feet per second, and 4 is 10^3 cubic meters per second
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import  WRTDS
#' @export
#' @return Daily dataframe 
#' @examples
#' getPreLoadedDailyData(ChoptankRiverFlow, interactive=FALSE)
getPreLoadedDailyData <- function (loadedData,qUnit=1,interactive=TRUE){
  data <- getPreLoadedData(loadedData)
  convertQ<-c(35.314667,1)
  qConvert<-convertQ[qUnit]
  if (interactive){
    if(qUnit==1) cat("\n the input discharge are assumed to be in cubic feet per second\nif they are in cubic meters per second, then the call to getPreLoadedDailyData should specify qUnit=2\n")
  }
  localDaily <- populateDaily(data,qConvert, interactive=interactive)
  return(localDaily)
}

#' Import Daily Data for WRTDS
#'
#' Imports data from a user-supplied file, and converts it to a Daily data frame, appropriate for WRTDS calculations.
#'
#' @param filePath string specifying the path to the file
#' @param fileName string name of file to open
#' @param hasHeader logical true if the first row of data is the column headers
#' @param separator string character that separates data cells
#' @param qUnit number 1 is cubic feet per second, 2 is cubic meters per second, 3 is 10^3 cubic feet per second, and 4 is 10^3 cubic meters per second
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import file
#' @keywords data import USGS WRTDS
#' @export
#' @return Daily dataframe
#' @examples
#' # Examples of how to use getDailyDataFromFile:
#' # Change the file path and file name to something meaningful:
#' #filePath <-  '~/RData/'  # Sample format
#' fileName <- 'ChoptankRiverFlow.txt'
#' #getDailyDataFromFile(filePath,fileName,separator="\t")
getDailyDataFromFile <- function (filePath,fileName,hasHeader=TRUE,separator=",",qUnit=1,interactive=TRUE){
  data <- getDataFromFile(filePath,fileName,hasHeader=hasHeader,separator=separator)
  convertQ<-c(35.314667,1)
  qConvert<-convertQ[qUnit]
  if (interactive){
    if(qUnit==1) cat("\n the input discharge are assumed to be in cubic feet per second\nif they are in cubic meters per second, then the call to getDailyDataFromFile should specify qUnit=2\n")
  }
  localDaily <- populateDaily(data,qConvert, interactive=interactive)
  return(localDaily)
}

#' Import Sample Data for WRTDS
#'
#' Imports data from NWIS web service. This function gets the data from here: \url{http://qwwebservices.usgs.gov/}
#' A list of parameter codes can be found here: \url{http://nwis.waterdata.usgs.gov/nwis/pmcodes/}
#' A list of statistic codes can be found here: \url{http://nwis.waterdata.usgs.gov/nwis/help/?read_file=stat&format=table}
#'
#' @param siteNumber string USGS site number.  This is usually an 8 digit number
#' @param ParameterCd string USGS parameter code.  This is usually an 5 digit number.
#' @param StartDate string starting date for data retrieval in the form YYYY-MM-DD.
#' @param EndDate string ending date for data retrieval in the form YYYY-MM-DD.
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import USGS WRTDS
#' @export
#' @return Sample dataframe
#' @seealso \code{\link{compressData}}, \code{\link{populateSampleColumns}}
#' @examples
#' # These examples require an internet connection to run
#' getSampleData('01594440','01075', '1985-01-01', '1985-03-31', interactive=FALSE)
#' getSampleData('05114000','00915;00931', '1985-01-01', '1985-03-31', interactive=FALSE)
#' getSampleData('05114000','00915;00931', '', '', interactive=FALSE)
getSampleData <- function(siteNumber,ParameterCd,StartDate,EndDate,interactive=TRUE){
  data <- getQWData(siteNumber,ParameterCd,StartDate,EndDate,interactive=interactive)
  compressedData <- compressData(data, interactive=interactive)
  Sample <- populateSampleColumns(compressedData)
  return(Sample)
}

#' Import Preloaded Sample Data for WRTDS use
#'
#' This function is intended to convert sample data that is already loaded into the R enviornment to the WRTDS daily data frame.
#'
#' @param loadedData dataframe that is already loaded in R session
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import  WRTDS
#' @export
#' @return Sample dataframe 
#' @examples
#' getPreLoadedSampleData(ChoptankRiverNitrate, interactive=FALSE)
getPreLoadedSampleData <- function (loadedData,interactive=TRUE){
#   data <- as.data.frame(loadedData, stringsAsFactors=FALSE)
  data <- getPreLoadedQWData(loadedData)
  compressedData <- compressData(data,interactive=interactive)
  Sample <- populateSampleColumns(compressedData)
  return(Sample)
}

#' Import Sample Data for WRTDS
#'
#' Imports data from a user-supplied file, and converts it to a Sample data frame, appropriate for WRTDS calculations.
#'
#' @param filePath string specifying the path to the file
#' @param fileName string name of file to open
#' @param hasHeader logical true if the first row of data is the column headers
#' @param separator string character that separates data cells
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import file
#' @keywords data import USGS WRTDS
#' @export
#' @return Sample dataframe
#' @examples
#' # Examples of how to use getSampleDataFromFile:
#' # Change the file path and file name to something meaningful:
#' #filePath <- '~/RData/'  # Sample format
#' fileName <- 'ChoptankRiverNitrate.csv'
#' #getSampleDataFromFile(filePath,fileName, separator=";",interactive=FALSE)
getSampleDataFromFile <- function (filePath,fileName,hasHeader=TRUE,separator=",", interactive=TRUE){
  data <- getQWDataFromFile(filePath,fileName,hasHeader=hasHeader,separator=separator)
  compressedData <- compressData(data, interactive=interactive)
  Sample <- populateSampleColumns(compressedData)
  return(Sample)
}

#' Import Metadata for USGS Data
#'
#' Populates INFO data frame for WRTDS study.  If either station number or parameter code supplied, imports data about a particular USGS site from NWIS web service. 
#' This function gets the data from here: \url{http://waterservices.usgs.gov/}
#' A list of parameter codes can be found here: \url{http://nwis.waterdata.usgs.gov/nwis/pmcodes/}
#' If either station number or parameter code is not supplied, the user will be asked to input data.
#' Additionally, the user will be asked for:
#' staAbbrev - station abbreviation, will be used in naming output files and for structuring batch jobs
#' constitAbbrev - constitute abbreviation
#'
#' @param siteNumber string USGS site number.  This is usually an 8 digit number
#' @param parameterCd string USGS parameter code.  This is usually an 5 digit number.
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import USGS web service WRTDS
#' @export
#' @return INFO dataframe with agency, site, dateTime, value, and code columns
#' @examples
#' # These examples require an internet connection to run
#' # Automatically gets information about site 05114000 and temperature, no interaction with user
#' getMetaData('05114000','00010',interactive=FALSE)
getMetaData <- function(siteNumber="", parameterCd="",interactive=TRUE){
  if (nzchar(siteNumber)){
    INFO <- getSiteFileData(siteNumber,interactive=interactive)
  } else {
    INFO <- as.data.frame(matrix(ncol = 2, nrow = 1))
    names(INFO) <- c('site.no', 'shortName')    
  }
  INFO <- populateSiteINFO(INFO, siteNumber, interactive=interactive)
  
  if (nzchar(parameterCd)){
    parameterData <- getParameterInfo(parameterCd,interactive=interactive)
    INFO$param.nm <- parameterData$parameter_nm
    INFO$param.units <- parameterData$parameter_units
    INFO$paramShortName <- parameterData$srsname
    INFO$paramNumber <- parameterData$parameter_cd
  } 

  INFO <- populateParameterINFO(INFO, parameterCd, interactive=interactive)

  return(INFO)
}

#####################################################################################################
# # Additional functions to set up data for WRTDS:
# 
#' Merge Sample and Daily Data for WRTDS
#'
#' Merges the flow data from the daily record into the sample record.
#'
#' @param localDaily dataframe containing the daily data, default is Daily
#' @param localSample dataframe containing the sample data, default is Sample
#' @param interactive logical Option for interactive mode.  If true, there is user interaction for error handling and data checks.
#' @keywords data import USGS WRTDS
#' @export
#' @return newSample dataframe with merged flow information
#' @seealso \code{\link{getDVData}}, \code{\link{populateSampleColumns}}
#' @examples
#' # These examples require an internet connection to run
#' exDaily <- getDVData('01594440','00060', '1985-01-01', '1985-03-31', interactive=FALSE)
#' exSample <- getSampleData('01594440','01075', '1985-01-01', '1985-03-31', interactive=FALSE)
#' mergeReport(localDaily = exDaily, localSample = exSample, interactive=FALSE)
mergeReport<-function(localDaily = Daily, localSample = Sample, interactive=TRUE){
  if (interactive){
    dataOverview(localDaily, localSample)  
  }
  julFirst<-localDaily$Julian[1]
	sampleDate<-as.Date(localSample$Date)
	sampleJulian<-as.numeric(julian(sampleDate,origin=as.Date("1850-01-01")))
  sampleIndex <- sampleJulian-julFirst+1
  Q <- localDaily$Q[sampleIndex]  
	LogQ<-log(Q)
	newSample<-data.frame(localSample,Q,LogQ)
  return(newSample)
}

#' Data Overview for WRTDS
#'
#' Gives a summary of data to be used for WRTDS analysis
#'
#' @param localDaily dataframe
#' @param localSample dataframe
#' @keywords data import USGS WRTDS
#' @export
#' @seealso \code{\link{mergeReport}}
#' @examples
#' # These examples require an internet connection to run
#' exDaily <- getDVData('01594440','00060', '1985-01-01', '1985-03-31', interactive=FALSE)
#' exSample <- getSampleData('01594440','01075', '1985-01-01', '1985-03-31', interactive=FALSE)
#' dataOverview(localDaily = exDaily, localSample = exSample)
dataOverview <- function(localDaily = Daily, localSample = Sample){
  numDays<-length(localDaily$Date)
  numSamples<-length(localSample$Date)
	numYears<-round(numDays/365.25,digits=0)
	cat("\n Discharge Record is",numDays,"days long, which is",numYears,"years")
	cat("\n First day of the discharge record is", as.character(localDaily$Date[1]),"and last day is",as.character(localDaily$Date[numDays]))
	cat("\n The water quality record has",numSamples,"samples")
	cat("\n The first sample is from", as.character(localSample$Date[1]),"and the last sample is from",as.character(localSample$Date[numSamples]))
	if(localSample$Date[1]<localDaily$Date[1]) cat("\n WE HAVE A PROBLEM first sample is from before the first daily discharge")	
	if(localSample$Date[numSamples]>localDaily$Date[numDays]) cat("\n WE HAVE A PROBLEM last sample is from after the last daily discharge")
	Qmin<-signif(min(localDaily$Q),digits=3)
	Qmean<-signif(mean(localDaily$Q),digits=3)
	Qmax<-signif(max(localDaily$Q),digits=3)
	Cmin<-signif(min(localSample$ConcHigh),digits=2)
	Cmean<-signif(mean(localSample$ConcHigh),digits=2)
	Cmax<-signif(max(localSample$ConcHigh),digits=2)
	cat("\n Discharge: Minimum, mean and maximum",Qmin,Qmean,Qmax)
	cat("\n Concentration: Minimum, mean and maximum",Cmin,Cmean,Cmax)
	pct<-sum(localSample$Uncen)
	pct<-((numSamples-pct)/numSamples)*100
	cat("\n Percentage of the sample values that are censored is",signif(pct,digits=2),"%")
}

#####################################################################################################






